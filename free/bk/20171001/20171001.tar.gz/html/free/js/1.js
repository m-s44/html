var test = "test";
let hoge = "hoge";
const hello = "hello";


function sample() {
  console.log(test);
  console.log(hoge);
  console.log(hello);
}

function sample_2() {
  let str = "文字";
  var num = 1;
  const bool = true;
}

for (let i = 0; i < 3; i++) {
  let str = "文字";
  var num = 1;
  const bool = true;
}


let hoge = "hogehoge";
console.log(hoge);

sample();




